const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// In-memory user storage (will be lost on server restart)
let users = [];

// Try to load existing users from file
const fs = require('fs');
const usersFile = path.join(__dirname, 'users.json');

try {
  if (fs.existsSync(usersFile)) {
    const data = fs.readFileSync(usersFile, 'utf8');
    users = JSON.parse(data);
    console.log(`✅ Loaded ${users.length} existing users`);
  }
} catch (err) {
  console.log("No existing users file, starting fresh");
}

// Save users to file
function saveUsers() {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// Add demo user if none exist
if (users.length === 0) {
  const bcrypt = require('bcrypt');
  const hashedPassword = bcrypt.hashSync('mut2026', 10);
  users.push({
    email: "student@mut.ac.za",
    password: hashedPassword,
    name: "Thabo",
    phone: "+27781234567",
    createdAt: new Date().toISOString()
  });
  saveUsers();
  console.log("✅ Demo user created: student@mut.ac.za / mut2026");
}

// ================= API ROUTES =================

// SIGNUP
app.post('/api/signup', async (req, res) => {
  try {
    const { email, password, phone, name } = req.body;

    if (!email || !password) {
      return res.json({ success: false, message: "Email and password required" });
    }

    // Check if user already exists
    const existingUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existingUser) {
      return res.json({ success: false, message: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = {
      email: email.toLowerCase(),
      password: hashedPassword,
      name: name || email.split('@')[0],
      phone: phone || '',
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers();

    console.log(`✅ New user registered: ${email}`);
    res.json({ 
      success: true, 
      user: { 
        email: newUser.email, 
        name: newUser.name, 
        phone: newUser.phone 
      } 
    });
  } catch (err) {
    console.error("Signup error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// LOGIN
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (!user) {
      return res.json({ success: false, message: "Invalid email or password" });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.json({ success: false, message: "Invalid email or password" });
    }

    res.json({ 
      success: true, 
      user: { 
        email: user.email, 
        name: user.name, 
        phone: user.phone 
      } 
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// LOGOUT
app.post('/api/logout', (req, res) => {
  res.json({ success: true });
});

// GET ALL USERS (for admin purposes)
app.get('/api/users', (req, res) => {
  const safeUsers = users.map(u => ({ 
    email: u.email, 
    name: u.name, 
    phone: u.phone,
    createdAt: u.createdAt 
  }));
  res.json({ success: true, users: safeUsers });
});

// ================= ENHANCED CHATBOT =================
app.post('/api/chat', (req, res) => {
  const message = req.body.message.toLowerCase();

  let reply = "I'm MUTi 🤖, your smart MUT assistant. Ask me about admissions, exams, graduation, remarking, courses, contacts, or university information.";

  // ================= ADDRESS =================
  if (message.includes("address") || message.includes("location")) {
    reply = `
📍 MUT Physical Address:

511 Mangosuthu Highway
Umlazi, Durban
KwaZulu-Natal
South Africa

📮 Postal Address:
The Registrar
Mangosuthu University of Technology
P.O Box 12363
Jacobs, Durban
4026
South Africa
`;
  }

  // ================= CONTACT =================
  else if (message.includes("contact") || message.includes("phone") || message.includes("call")) {
    reply = `
☎️ MUT Contact Details

Switchboard:
(031) 907-7111

Fax:
(031) 907-2892
(031) 907-7257

🌐 Website:
http://www.mut.ac.za
`;
  }

  // ================= BANKING =================
  else if (message.includes("bank") || message.includes("banking") || message.includes("payment")) {
    reply = `
🏦 MUT Banking Details

Bank: ABSA
Account Number: 4063827633
Branch Code: 632005
`;
  }

  // ================= FRAUD =================
  else if (message.includes("fraud") || message.includes("corruption") || message.includes("report")) {
    reply = `
🚨 Fraud & Corruption Reporting

Deloitte Tip-offs Hotline:
0800 228 999

🌐 Website:
www.tips-off.com
`;
  }

  // ================= HISTORY =================
  else if (message.includes("history") || message.includes("overview")) {
    reply = `
📚 MUT Historical Overview

The idea of MUT began in 1974 to address the shortage of technicians in South Africa.

Teaching officially started in 1979.

In November 2007, Mangosuthu Technikon became Mangosuthu University of Technology.
`;
  }

  // ================= VISION =================
  else if (message.includes("vision")) {
    reply = `
🎯 MUT Vision

To be a transforming, equitable, sustainable, and academically excellent University of Technology anchored in its communities.
`;
  }

  // ================= MISSION =================
  else if (message.includes("mission")) {
    reply = `
🚀 MUT Mission

To offer technological and career-directed programmes focusing on innovative problem-solving research and community engagement.
`;
  }

  // ================= VALUES =================
  else if (message.includes("values") || message.includes("principles")) {
    reply = `
⭐ MUT Values

• Accountability
• Integrity
• Respect
• Excellence
`;
  }

  // ================= VICE CHANCELLOR =================
  else if (message.includes("vice chancellor") || message.includes("principal")) {
    reply = `
👨‍💼 Vice-Chancellor & Principal

Prof N. Sibiya
`;
  }

  // ================= FACULTIES =================
  else if (message.includes("faculty") || message.includes("faculties")) {
    reply = `
🏫 MUT Faculties

1️⃣ Engineering

2️⃣ Management Sciences

3️⃣ Applied & Health Sciences
`;
  }

  // ================= ICT DEPARTMENT =================
  else if (message.includes("ict") || message.includes("information technology")) {
    reply = `
💻 ICT Department

Head of Department:
Dr V. Jugoo

The department focuses on:
• Software Development
• Networking
• Databases
• Cybersecurity
• Web Development
`;
  }

  // ================= COURSES =================
  else if (message.includes("course") || message.includes("program")) {
    reply = `
📘 MUT Programmes

• Diploma
• Advanced Diploma
• Extended Curriculum Programme

Popular fields:
• ICT
• Engineering
• Accounting
• Agriculture
• Environmental Health
`;
  }

  // ================= CAREERS =================
  else if (message.includes("career") || message.includes("jobs")) {
    reply = `
💼 Career Opportunities

• Software Developer
• Data Analyst
• Cybersecurity Specialist
• Network Engineer
• Database Administrator
• Web Developer
`;
  }

  // ================= EXAMS =================
  else if (message.includes("exam") || message.includes("test")) {
    reply = `
📝 2026 Examination Dates

First Semester Exams:
19 May 2026 – 01 June 2026

Second Semester Exams:
04 November 2026 – 17 November 2026
`;
  }

  // ================= REMARKING =================
  else if (message.includes("remark") || message.includes("remarking")) {
    reply = `
📄 Remarking Applications

Remarking period:
23 October 2026 – 27 October 2026

Applications are submitted after exam results are released.
`;
  }

  // ================= GRADUATION =================
  else if (message.includes("graduation") || message.includes("graduate")) {
    reply = `
🎓 2026 Graduation Ceremonies

Engineering:
21 April 2026

Management Sciences:
22 April 2026

Applied & Health Sciences:
23 April 2026
`;
  }

  // ================= SEMESTERS =================
  else if (message.includes("semester") || message.includes("term")) {
    reply = `
📅 2026 Academic Terms

Semester 1:
05 January – 19 June 2026

Semester 2:
13 July – 15 December 2026
`;
  }

  // ================= REGISTRATION =================
  else if (message.includes("registration") || message.includes("register")) {
    reply = `
📝 Registration Information

New students registration begins:
19 January 2026

Lectures commence:
02 February 2026
`;
  }

  // ================= CHATBOT NAME =================
  else if (message.includes("who are you") || message.includes("your name")) {
    reply = `
🤖 My name is MUTi.

The name combines:
• MUT (Mangosuthu University of Technology)
• AI intelligent assistant personality

I help students quickly access university information in a smart interactive way.
`;
  }

  res.json({ reply });
});

// ================= SERVE HTML PAGES =================
// Default route - goes to welcome.html (but will redirect to login if not authenticated via frontend)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'welcome.html'));
});

app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/welcome.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'welcome.html'));
});

app.get('/index.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/why.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'why.html'));
});

app.get('/course.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'course.html'));
});

app.get('/careers.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'careers.html'));
});

app.get('/admission.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admission.html'));
});

app.get('/database.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'database.html'));
});

app.get('/profile.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

app.get('/image-processing.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'image-processing.html'));
});

// ================= START SERVER =================
app.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════════════════════════════╗`);
  console.log(`║                                                              ║`);
  console.log(`║   🚀 MUT ICT SERVER IS RUNNING!                              ║`);
  console.log(`║                                                              ║`);
  console.log(`║   📁 Open: http://localhost:${PORT}/                           ║`);
  console.log(`║          (Welcome page - will redirect to login if needed)   ║`);
  console.log(`║                                                              ║`);
  console.log(`║   🔐 Demo Login: student@mut.ac.za / mut2026                 ║`);
  console.log(`║                                                              ║`);
  console.log(`║   💾 Users are stored in users.json (No database needed!)    ║`);
  console.log(`║                                                              ║`);
  console.log(`║   🤖 Chatbot MUTi is ready!                                  ║`);
  console.log(`║      Ask about: address, contact, banking, fraud,           ║`);
  console.log(`║      history, vision, mission, values, VC, faculties,       ║`);
  console.log(`║      ICT, courses, careers, exams, remarking,               ║`);
  console.log(`║      graduation, semesters, registration                     ║`);
  console.log(`║                                                              ║`);
  console.log(`╚══════════════════════════════════════════════════════════════╝\n`);
  console.log(`📊 Current users: ${users.length}`);
});