app.post('/api/chat', (req, res) => {
  const msg = req.body.message.toLowerCase();

  let reply = "Hi, I am MUTi 🤖 — your ICT assistant.";

  if (msg.includes("exam")) {
    reply = "Exams are held in scheduled MUT exam venues announced on the portal.";
  }
  else if (msg.includes("remark")) {
    reply = "Remarking costs apply and must be requested within 7 days of results.";
  }
  else if (msg.includes("venue")) {
    reply = "Venues are displayed on your student timetable system.";
  }
  else if (msg.includes("career")) {
    reply = "ICT careers include Software Developer, Cybersecurity Analyst, and Data Engineer.";
  }

  res.json({ reply });
});